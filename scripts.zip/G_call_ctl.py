#!/usr/bin/env python
'''

    THIS SCRIPT SHOULD BE RUN ON THE RECIVING TURRETS TO AUTOMATICALLY PICK UP LINES

'''
from subprocess import call
from time import sleep
import random
import re #for multiple delimter splitting

print "Pickup Load Test"

def mSpeedial(number):
    call(["G_station", "--msg", "SPEEDIAL_"+number])

def mSleep(cSeconds):
    print cSeconds
    if 'RANDOM' in cSeconds:
        #sleep(float(cSeconds))
        print 'Random sleep'+cSeconds
        cSecT = re.split(' |,', cSeconds)
        #print cSecT[1], cSecT[2]
        sleep(random.randint(float(cSecT[1]), float(cSecT[2])))
        return
    sleep(float(cSeconds))


def mDialNumber(number):
    for cC in number:
        call(["G_station", "--msg", "DIAL_"+cC])
        sleep(0.25)
    call(["G_station", "--msg", "DIAL_11"])

def mDrop(handset):
    call(["G_station", "--msg", "ACTION_DROP_"+handset])

def mSwitch(handset):
    call(["G_station", "--msg", "ACTION_SWITCH_"+handset])

def mHold(handset):
    call(["G_station", "--msg", "ACTION_HOLD_"+handset])

def mAccess(handset):
    call(["G_station", "--msg", "ACCESS_"+handset])

def cCommand(cmd):
    instrc = cmd.split('_')
    print instrc[0]
    if instrc[0] == 'SPEEDIAL':
        mSpeedial(instrc[1])
    elif instrc[0] == 'SLEEP':
        mSleep(instrc[1])
    elif instrc[0] == 'DIAL':
        mDialNumber(instrc[1])
    elif instrc[0] == 'DROP':
        mDrop(instrc[1])
    elif instrc[0] == 'SWITCH':
        mSwitch(instrc[1])
    elif instrc[0] == 'HOLD':
        mHold(instrc[1])
    elif instrc[0] == 'ACCESS':
        mAccess(instrc[1])
    else:
        pass

#users the button range list
def runTestWithRange(mPositionRange):
    print mPositionRange
    nPositons = []
    for nRange in mPositionRange:
        nStart, nStop = nRange.split('-')
        for nPosition in range(int(nStart), int(nStop)+1):
            nPositons.append(str(nPosition))

    print nPositons
    mLength =  len(nPositons)
    while(1):
        nPositon = int(nPositons[random.randint(0,mLength-1)])
        cCommand('ACCESS_{}'.format((nPositon)))
        cCommand('SLEEP_RANDOM 10,20')
        if nPositon%2 == 0:
            cCommand('DROP_1')
        else:
            cCommand('HOLD_1')
        cCommand('SLEEP_RANDOM 2,4')

#uses the button positions list
def runTestWithPositions(nPositons):
    print nPositons
    mLength =  len(nPositons)
    while(1):
        nPositon = int(nPositons[random.randint(0,mLength-1)])
        cCommand('ACCESS_{}'.format((nPositon)))
        cCommand('SLEEP_RANDOM 10,20')
        if nPositon%2 == 0:
            cCommand('DROP_1')
        else:
            cCommand('HOLD_1')
        cCommand('SLEEP_RANDOM 2,4')


nPositons = [\
    '0',\
    '2',\
    '11',\
    '13',\
    '18',\
    '20',\
    '25',\
    '27',\
    '32',\
    '34',\
    '42',\
    '43',\
    '44',\
    '45',\
    '2300',\
    '2301',\
    '2302',\
    '2303',\
    '2304',\
    '2305',\
    '2306',\
    '2307',\
    '2350',\
    '2351',\
    '2352',\
    '2353',\
    '2354',\
    '2355',\
    '2356',\
    '2357',\
    '2358',\
    '2359',\
    '2360',\
    '2361',\
    '2362',\
    '2363',\
    '2364',\
    '2365',\
    '2366',\
    '2367',\
    '2368',\
    '2369',\
    '2374',\
    '2375',\
    '2376',\
    '2377',\
    '2382',\
    '2383',\
    '2384',\
    '2385',\
    '2386',\
    '2387',\
    '2388',\
    '2389',\
    '2400',\
    '2401',\
    '2402',\
    '2403',\
    '2405',\
    '2406',\
    '2407',\
    '2408',\
    '2410',\
    '2411',\
    '2412',\
    '2413',\
    '2415',\
    '2416',\
    '2417',\
    '2418',\
    '2420',\
    '2421',\
    '2422',\
    '2423',\
    '2425',\
    '2426',\
    '2427',\
    '2428',\
    '2430',\
    '2431',\
    '2432',\
    '2433',\
    '2450',\
    '2451',\
    '2452',\
    '2453',\
    '2454',\
    '2455',\
    '2456',\
    '2457',\
    '2458',\
    '2459',\
    '2460',\
    '2461',\
    '2462',\
    '2463',\
    '2464',\
    '2465',\
    ]
#mPositionRange = [\
    #'351-360',\
    #'363-365',\
    #]

runTestWithPositions(nPositons)
#runTestWithRange(mPositionRange)

