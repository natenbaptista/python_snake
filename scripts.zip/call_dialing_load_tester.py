#!/usr/bin/env python
from subprocess import call
from time import sleep
import random
import re #for multiple delimter splitting
'''

    THIS SCRIPT SHOULD BE RUN ON THE BROADCASTING CALLING SINGLE TURRET
    TO CALL THE LINES ON THE OTHER SYSTEM

'''

print "Dialing Load Test"

def latch_channel(ichannel, slatch):
    channel = "CONTROL_PANEL_SKP_%d_PTL_%s_" % (ichannel, slatch)
    call(["G_station", "--msg", channel])
    time.sleep(0.1)

def mSpeedial(number):
    call(["G_station", "--msg", "SPEEDIAL_"+number])

def mSleep(cSeconds):
    print cSeconds
    if 'RANDOM' in cSeconds:
        #sleep(float(cSeconds))
        print 'Random sleep'+cSeconds
        cSecT = re.split(' |,', cSeconds)
        #print cSecT[1], cSecT[2]
        sleep(random.randint(float(cSecT[1]), float(cSecT[2])))
        return
    sleep(float(cSeconds))


def mDialNumber(number):
    for cC in number:
        call(["G_station", "--msg", "DIAL_"+cC])
        sleep(0.25)
    call(["G_station", "--msg", "DIAL_11"])

def mDrop(handset):
    call(["G_station", "--msg", "ACTION_DROP_"+handset])

def mSwitch(handset):
    call(["G_station", "--msg", "ACTION_SWITCH_"+handset])

def mHold(handset):
    call(["G_station", "--msg", "ACTION_HOLD_"+handset])

def mAccess(handset):
    call(["G_station", "--msg", "ACCESS_"+handset])

def cCommand(cmd):
    instrc = cmd.split('_')
    print instrc[0]
    if instrc[0] == 'SPEEDIAL':
        mSpeedial(instrc[1])
    elif instrc[0] == 'SLEEP':
        mSleep(instrc[1])
    elif instrc[0] == 'DIAL':
        mDialNumber(instrc[1])
    elif instrc[0] == 'DROP':
        mDrop(instrc[1])
    elif instrc[0] == 'SWITCH':
        mSwitch(instrc[1])
    elif instrc[0] == 'HOLD':
        mHold(instrc[1])
    elif instrc[0] == 'ACCESS':
        mAccess(instrc[1])
    else:
        pass

def make_call(line):
    number, position = line.split('_')
    cCommand('SPEEDIAL_'+number)
    cCommand('SLEEP_RANDOM 1,2')
    cCommand('HOLD_1')
    cCommand('SLEEP_RANDOM 2,4')

def drop_call(line):
    number, position = line.split('_')
    cCommand('ACCESS_{}'.format((int(position))))
    cCommand('SLEEP_RANDOM 1,2')
    cCommand('DROP_1')
    cCommand('SLEEP_RANDOM 2,4')


def runTest(mlines):
    print mlines
    for line in mlines:
        make_call(line)

    while(1):
        for line in mlines:
            drop_call(line)
            make_call(line)

'''
 The mlines is an array which needs to be loaded with speedial number + button positions
 So in this case [Speeddial number]_[button position].
'''

mlines = [\
    '442074963044_0',\
    '442074963001_2',\
    '442074963040_11',\
    '442074963097_13',\
    '442074963003_18',\
    '442074963031_20',\
    '442074963035_25',\
    '442074963033_27',\
    '442074963002_32',\
    '442074963032_34',\
    '442074963030_42',\
    '442074963030_43',\
    '442074963030_44',\
    '442074963030_45',\
    '442074963001_2300',\
    '442074963001_2301',\
    '442074963001_2302',\
    '442074963001_2303',\
    '442074963097_2304',\
    '442074963097_2305',\
    '442074963097_2306',\
    '442074963097_2307',\
    '442074963032_2350',\
    '442074963032_2351',\
    '442074963032_2352',\
    '442074963032_2353',\
    '442074963033_2354',\
    '442074963033_2355',\
    '442074963033_2356',\
    '442074963033_2357',\
    '442074963003_2358',\
    '442074963003_2359',\
    '442074963003_2360',\
    '442074963003_2361',\
    '442074963031_2362',\
    '442074963031_2363',\
    '442074963031_2364',\
    '442074963031_2365',\
    '442074963035_2366',\
    '442074963035_2367',\
    '442074963035_2368',\
    '442074963035_2369',\
    '442074963044_2374',\
    '442074963044_2375',\
    '442074963044_2376',\
    '442074963044_2377',\
    '442074963040_2382',\
    '442074963040_2383',\
    '442074963040_2384',\
    '442074963040_2385',\
    '442074963002_2386',\
    '442074963002_2387',\
    '442074963002_2388',\
    '442074963002_2389',\
    '442074963010_2400',\
    '442074963010_2401',\
    '442074963010_2402',\
    '442074963010_2403',\
    '442074963012_2405',\
    '442074963012_2406',\
    '442074963012_2407',\
    '442074963012_2408',\
    '442074963015_2410',\
    '442074963015_2411',\
    '442074963015_2412',\
    '442074963015_2413',\
    '442074963016_2415',\
    '442074963016_2416',\
    '442074963016_2417',\
    '442074963016_2418',\
    '442074963013_2420',\
    '442074963013_2421',\
    '442074963013_2422',\
    '442074963013_2423',\
    '442074963004_2425',\
    '442074963004_2426',\
    '442074963004_2427',\
    '442074963004_2428',\
    '442074963014_2430',\
    '442074963014_2431',\
    '442074963014_2432',\
    '442074963014_2433',\
    '442074963021_2450',\
    '442074963021_2451',\
    '442074963021_2452',\
    '442074963021_2453',\
    '442074963023_2454',\
    '442074963023_2455',\
    '442074963023_2456',\
    '442074963023_2457',\
    '442074963190_2458',\
    '442074963190_2459',\
    '442074963190_2460',\
    '442074963190_2461',\
    '442074963022_2462',\
    '442074963022_2463',\
    '442074963022_2464',\
    '442074963022_2465',\
    ]


#mlines = [\
    #'6000_1',\
    #'6001_2',\
    #'6002_3',\
    #'6003_4',\
    #'6004_5',\
    #'6005_6',\
    #'6006_7',\
    #'6007_8',\
    #'6008_9',\
    #'6009_10',\
    #'6010_11',\
    #'6011_12',\
    #'6012_13',\
    #]

runTest(mlines)

42074963044
6000